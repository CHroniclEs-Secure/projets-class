# -*- coding: utf-8 -*-
import random
import pkgclients.Client as cl

def informationClient(fichierClients="clients.txt"):  # Question de depart pour lire le fichier
    clients = []  # dictionnaire class CLient - liste
    with open(fichierClients, 'r') as fichiers:  # Ouverture du dossier
        for line in fichiers:  # Pour lire par ligne
            numClient, prenomClient, nomClient, nipClient, solde = line.strip().split(";")  # couper apres le ";"
            clientx = cl.Client(numClient, prenomClient, nomClient, nipClient, solde)  # on met les instances
            clients.append(clientx)  # on ajoute les instances aux clients liste/dictionnaire
    return clients

def menuPrincipal():  # fonction pour les options du menu apres avoir lu le fichier
    choix_d_option = print("======================================================= \n"
                           "|              M E N U    D ' O P T I O N S           | \n"
                           "|=====================================================| \n"
                           "|   1. Produire liste de transactions                 | \n"
                           "|   2. Modifier Solde                                 | \n"
                           "|   3. Réinitialisation de NIP                        | \n"
                           "|   4. Enregistrer les données                        | \n"
                           "|   5. Quitter                                        | \n"
                           "======================================================= \n")
    return choix_d_option

def listeTransactions(clients):  # option 1 - affiche de la liste d'information des clients
    print("***************************************************\n"
          "     Vous avez choisi Opt. 1 - Liste Transaction   \n"
          "****************************************************\n\n"
          "======================================================= \n"
          "           Liste des informations des clients           \n"
          "======================================================= \n")
    for client in clients:  # lecture de chaque valeur/information
        print(client.getNumClient(), client.getPrenomClient(), client.getNomClient(),
              client.getNIPClient(), "{:.2f}".format(client.getSolde()))  #"{:.2}".format() - fonction formatage pour decimal .00

    while True:
        print("======================================================= \n")
        retourner_au_menu = input("Vouillez appuyer sur 'ENTER' pour retourner au menu principal: ")
        if retourner_au_menu == '':
            return

def modifierSolde(clients, fichierClients="clients.txt"):
    nomClient = input("****************************************************\n"
                      "     Vous avez choisi Opt. 2 - Modifier Solde       \n"
                      "****************************************************\n"
                      "     >>> Entrez nom famille du client:     \n")
    for client in clients:
        if client.getNomClient() == nomClient:
            print("=======================\n"
                  "|Client sélectionné:  |\n",
                  "|", client.getPrenomClient(), client.getNomClient(), "|")
            print("=======================\n"
                  "|Solde actuel:        |\n",
                  "|", client.getSolde(), "|")
            while True:
                try:
                    print("=================================================\n"
                          "Saisir le nouveau solde(entre -10000$ et 10000$):  ")
                    nouveauSolde = float(input("$"))
                    if nouveauSolde < -10000 or nouveauSolde > 10000:
                        print("Erreur. Le solde doit être entre -10000$ et 10000$.")
                        continue
                    break
                except ValueError:
                    print("SVP, entrez un nombre valide.")

            client.setSolde(nouveauSolde)  # nouveau solde
            print("=================\n"
                  "|Nouveau Solde:  |\n",
                  client.getSolde(), "\n")
            with open(fichierClients, 'w') as fichiers:
                for client in clients:
                    fichiers.write(f"{client.getNumClient()};{client.getPrenomClient()};{client.getNomClient()};"
                                   f"{client.getNIPClient()};{client.getSolde()}\n")
            while True:
                retourner_au_menu = input("Vouillez appuyer sur 'ENTER' pour retourner au menu principal: ")
                if retourner_au_menu == '':
                    return
                else:
                    retourner_au_menu = input("Vouillez appuyer sur 'ENTER' pour retourner au menu principal: ")
    print("Aucun client avec ce nom n'a été trouvé.")
    return

def autreNIP(clients, fichierClients="clients.txt"):
    nomClient = input("****************************************************\n"
                      "     Vous avez choisi Opt. 3 - Réinitiliser NIP     \n"
                      "****************************************************\n"
                      "     >>> Entrez nom famille du client:     \n")
    for client in clients:
        if client.getNomClient() == nomClient:
            print("=======================\n"  # affichage des informations actuels 
                  "|Client sélectionné:  |\n",
                  "|", client.getPrenomClient(), client.getNomClient(), "|")
            print("=======================\n"
                  "|NIP actuel:        |\n",
                  "|", client.getNIPClient(), "|")
            nouveauNIP = str(random.randint(100000, 999999))  # generation du nouveau NIP pour le client.
            client.setNIPClient(nouveauNIP)
            print("=================\n"
                  "|Nouveau NIP:  |\n",
                  client.getNIPClient(), "\n"
                                         "=================\n")
            with open(fichierClients, 'w') as fichiers:
                for client in clients:
                    fichiers.write(f"{client.getNumClient()};{client.getPrenomClient()};{client.getNomClient()};"
                                   f"{client.getNIPClient()};{client.getSolde()}\n")
            while True:
                retourner_au_menu = input("Vouillez appuyer sur 'ENTER' pour retourner au menu principal: ")
                if retourner_au_menu == '':
                    return
                else:
                    retourner_au_menu = input("Vouillez appuyer sur 'ENTER' pour retourner au menu principal: ")
    print("Aucun client avec ce nom n'a été trouvé.")
    return

def enregistrementDonnees(clients, fichierClients="clients.txt"):
    print("****************************************************\n"
          "     Vous avez choisi Opt. 4 - Enregistrer Données  \n"
          "****************************************************\n")
    nouveauEnregistrement = input("Rentrez le nom du fichier pour le sauvegarder(clients.txt:")
    while "clients.txt" not in nouveauEnregistrement:
        print("Fichier inexistant.")
        nouveauEnregistrement = input("Rentrez le nom du fichier pour le sauvegarder(clients.txt:")
    if not nouveauEnregistrement:
        nouveauEnregistrement = "clients.txt"
        with open(fichierClients, 'w') as fichiers:
            fichiers.write(f"{client.getNumClient()};{client.getPrenomClient()};{client.getNomClient()};"
                           f"{client.getNIPClient()};{client.getSolde()}\n")
    print("Modification sauvegardée.")
    while True:
        retourner_au_menu = input("Vouillez appuyer sur 'ENTER' pour retourner au menu principal: \n")
        if retourner_au_menu == '':
            return
        else:
            retourner_au_menu = input("Vouillez appuyer sur 'ENTER' pour retourner au menu principal: ")
    print("Aucun client avec ce nom n'a été trouvé.")
    return

def sortir(clients, fichierClients="clients.txt"):
    print("****************************************************\n"
          "     Vous avez choisi Opt. 5 - Quitter              \n"
          "****************************************************\n")
    sauvegardeSortie = input("Voulez-vous enregistrer les modifications avant de quitter? (O/N):\n")
    if sauvegardeSortie.lower() == 'o':
        with open(fichierClients, 'w') as fichiers:
            for client in clients:
                fichiers.write(f"{client.getNumClient()};{client.getPrenomClient()};{client.getNomClient()};"
                               f"{client.getNIPClient()};{client.getSolde()}\n")
        print("Modifications sauvegardée.")
    elif sauvegardeSortie.lower() == 'n':
        print("Aucune modification n'a été enregistrée.")
    print("Merci d'avoir utilisé notre système. Au revoir!")
    exit()

# l'utilisateur choisit une option
print("=======================================================")
dataClient = input("SVP. Rentrez le nom du fichier(clients.txt):\n")
while "clients.txt" not in dataClient:
    print("Fichier incorrect.")
    dataClient = input("Entrez le nom du fichier(clients.txt):\n")
if not dataClient:
    dataClient = "clients.txt"

clients = informationClient(dataClient)

# corp de l'application
while True:
    menuPrincipal() #menu d'options
    while True:
        try:
            choix_d_option = int(input(" >>> Saisir votre choix( entre 1 et 5):\n\n"))
            if choix_d_option < 0 or choix_d_option > 5:  #restriction
                choix_d_option = int(input("Choix erroné. SVP, saisir à nouveau votre choix:\n"))
                continue
            break
        except ValueError:
            print("Saisir seulement des nombres entiers.")
    if choix_d_option == 1:
        listeTransactions(clients)  #méthode transactions
    elif choix_d_option == 2:
        modifierSolde(clients)      #métode changement de sole
    elif choix_d_option == 3:
        autreNIP(clients)           #méthode génération du code NIP
    elif choix_d_option == 4:
        enregistrementDonnees(clients)  #méthode enregistrement de données
    elif choix_d_option == 5:
        sortir(clients)         #option sortir