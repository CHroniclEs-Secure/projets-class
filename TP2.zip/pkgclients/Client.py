# -*- coding: utf-8 -*-
class Client:
    nombreClients = 0
    def __init__(self, numClient, prenomClient, nomClient, nipClient, solde):
        self.__numClient = numClient  # entier
        self.__prenomClient = prenomClient  # str
        self.__nomClient = nomClient  # str
        self.__nipClient = nipClient  # Code 6 caractères - str
        self.__solde = float(solde)  # float
        Client.nombreClients += 1

    # Getter
    def getNumClient(self):
        return (self.__numClient)

    def getPrenomClient(self):
        return (self.__prenomClient)

    def getNomClient(self):
        return (self.__nomClient)

    def getNIPClient(self):
        return (self.__nipClient)

    def getSolde(self):
        return (self.__solde)

    # Setter
    def setNumClient(self, numClient):
        self.__numClient = numClient

    def setPrenomClient(self, prenomClient):
        self.__prenomClient = prenomClient

    def setNomClient(self, nomClient):
        self.__nomClient = nomClient

    def setNIPClient(self, nipClient):
        self.__nipClient = nipClient

    def setSolde(self, solde):
        self.__solde = solde
